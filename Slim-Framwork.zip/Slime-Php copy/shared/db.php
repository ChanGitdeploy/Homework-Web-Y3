<?php

function getConnection(){
    $dsn = "mysql:host=127.0.0.1;dbname=STUDENS_DBMS"; // Use 127.0.0.1 instead of localhost
    $username = "root";
    $password = "";
    try {
        $pdo = new PDO($dsn, $username, $password);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;

    } catch (PDOException $e) {
        die("Connection failed! " . $e->getMessage());
    }
}
?>