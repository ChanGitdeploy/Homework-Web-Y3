<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
use Psr\Http\Server\RequestHandlerInterface;

require __DIR__ . '/../vendor/autoload.php';
require __DIR__ . '/../shared/db.php';

$app = AppFactory::create();

$app->add(function (Request $request, RequestHandlerInterface $handler) {
    $response = $handler->handle($request);

    return $response
        ->withHeader('Access-Control-Allow-Origin', '*')
        ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
        ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE')
        ->withHeader('Content-Type', 'application/json');
});


$app->options('/{routes:.+}', function (Request $request, Response $response) {
    return $response
        ->withHeader('Access-Control-Allow-Origin', '*')
        ->withHeader('Access-Control-Allow-Headers', 'X-Requested-With, Content-Type, Accept, Origin, Authorization')
        ->withHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
});


$app->get('/', function (Request $request, Response $response, $args) {
    $response->getBody()->write("Hello world b sl o!");
    return $response;
});
//get all user
$app->get('/STUDENTS', function (Request $request, Response $response, $args) {
    $pdo = getConnection();
    $sql = $pdo->query("SELECT * FROM STUDENTS WHERE is_active=1");
    $user = $sql->fetchAll(PDO::FETCH_ASSOC);
    $response->getBody()->write(json_encode($user));
    return $response;
});
//get by id
$app->addBodyParsingMiddleware();
$app->get('/user/{id}', function (Request $request, Response $response, $args) {
    $pdo = getConnection();
    $id = $args['id'];
    $sql = $pdo->prepare("SELECT * FROM users WHERE is_active=1 AND id=:id");
    $sql->execute(['id' => $id]);
    $user = $sql->fetch(PDO::FETCH_ASSOC);
    if (empty($user)) {
        $response->getBody()->write(json_encode(['error' => 'User not found!']));
        return $response->withStatus(404); 
    } else {
        $response->getBody()->write(json_encode($user));
        return $response;
    }
});
$app->addBodyParsingMiddleware();
$app->post('/STUDENTS/CREATE', function (Request $request, Response $response, $args) {
    $pdo = getConnection();
    $data = $request->getParsedBody();
    
    // Validate required fields
    $requiredFields = ['stu_name', 'stu_gender', 'stu_major', 'stu_email_edu', 'stu_class'];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty(trim($data[$field]))) {
            $response->getBody()->write(json_encode(['error' => "Please provide field: $field"]));
            return $response->withStatus(400);
        }
    }

    // Validate email format
    if (!filter_var($data['stu_email_edu'], FILTER_VALIDATE_EMAIL)) {
        $response->getBody()->write(json_encode(['error' => 'Invalid email format']));
        return $response->withStatus(400);
    }

    // Check if email already exists
    $checkEmail = $pdo->prepare("SELECT * FROM STUDENTS WHERE stu_email_edu = :stu_email_edu");
    $checkEmail->execute(['stu_email_edu' => $data['stu_email_edu']]);
    if ($checkEmail->fetch(PDO::FETCH_ASSOC)) {
        $response->getBody()->write(json_encode(['error' => 'Email already exists']));
        return $response->withStatus(409);
    }

    // Insert new student
    $sql = "INSERT INTO STUDENTS (stu_name, stu_gender, stu_major, stu_email_edu, stu_class) 
            VALUES (:stu_name, :stu_gender, :stu_major, :stu_email_edu, :stu_class)";
    $statement = $pdo->prepare($sql);

    try {
        $statement->execute([
            'stu_name' => $data['stu_name'],
            'stu_gender' => $data['stu_gender'],
            'stu_major' => $data['stu_major'],
            'stu_email_edu' => $data['stu_email_edu'],
            'stu_class' => $data['stu_class']
        ]);

        $response->getBody()->write(json_encode([
            'success' => 'Student created successfully',
            'id' => $pdo->lastInsertId()
        ]));
        return $response->withStatus(201);
    } catch (PDOException $e) {
        $response->getBody()->write(json_encode([
            'error' => 'Failed to create student',
            'details' => $e->getMessage()
        ]));
        return $response->withStatus(500);
    }
});
$app->put('/STUDENT/{id}', function (Request $request, Response $response, $args) {
    $pdo = getConnection();
    $id = $args['id'];
    $data = $request->getParsedBody();

    // Validate input
    $requiredFields = ['stu_name', 'stu_gender', 'stu_major', 'stu_email_edu', 'stu_class'];
    foreach ($requiredFields as $field) {
        if (!isset($data[$field]) || empty(trim($data[$field]))) {
            $response->getBody()->write(json_encode(['error' => "Missing field: $field"]));
            return $response->withStatus(400);
        }
    }

    // Validate email
    if (!filter_var($data['stu_email_edu'], FILTER_VALIDATE_EMAIL)) {
        $response->getBody()->write(json_encode(['error' => 'Invalid email format']));
        return $response->withStatus(400);
    }

    // Update query
    $sql = "UPDATE STUDENTS 
            SET stu_name = :stu_name, stu_gender = :stu_gender, stu_major = :stu_major, 
                stu_email_edu = :stu_email_edu, stu_class = :stu_class 
            WHERE stu_id = :stu_id AND is_active = 1";

    $stmt = $pdo->prepare($sql);

    try {
        $stmt->execute([
            'stu_name' => $data['stu_name'],
            'stu_gender' => $data['stu_gender'],
            'stu_major' => $data['stu_major'],
            'stu_email_edu' => $data['stu_email_edu'],
            'stu_class' => $data['stu_class'],
            'stu_id' => $id
        ]);

        if ($stmt->rowCount() === 0) {
            $response->getBody()->write(json_encode(['message' => 'No changes made or student not found']));
            return $response->withStatus(404);
        }

        $response->getBody()->write(json_encode(['message' => 'Student updated successfully']));
        return $response;
    } catch (PDOException $e) {
        $response->getBody()->write(json_encode([
            'error' => 'Failed to update student',
            'details' => $e->getMessage()
        ]));
        return $response->withStatus(500);
    }
});

//delete user
$app->put('/STUDENT/{id}', function (Request $request, Response $response, $args) {
    $id = $args['id'];  // Correct key
    $pdo = getConnection();

    $sql = $pdo->prepare("UPDATE STUDENTS SET is_active = 0 WHERE stu_id = :stu_id");
    $sql->execute(['stu_id' => $id]);

    if ($sql->rowCount() === 0) {
        $response->getBody()->write(json_encode(['message' => 'Student not found']));
        return $response->withStatus(404);
    } else {
        $response->getBody()->write(json_encode(['message' => 'Student deleted successfully']));
        return $response;
    }
});


$app->run();
